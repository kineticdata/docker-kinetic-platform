{
  'info' => {
    'server' => 'matrix.kineticdata.com',
    'port' => '25',
    'tls' => 'false',
    'username' => 'mary',
    'password' => 'kinetic'
  },
  'parameters' => {
    'from' => 'mary@matrix.kineticdata.com',
    'to' => 'mary@matrix.kineticdata.com',
    'subject' => 'Test Subject',
    'htmlbody' => "<html>Thanks from <img src=\"cid:http://www.kineticdata.com/images/Header.gif\"></html>",
    'textbody' => "Thanks from Kinetic Data."
  }
}

