# Require the REXML ruby gem.  This is already included in the Kinetic Task
# engine, but will need to be available in the local JRuby gem repository if the
# handler is being run manually.
require 'rexml/document'

# Require the necessary java libraries
require 'lib/activation.jar'
require 'lib/commons-email-1.2.jar'
require 'lib/mailapi.jar'
require 'lib/smtp.jar'

class SmtpEmailSendV1
  def initialize(input)
    # Set the input document attribute
    @input_document = REXML::Document.new(input)

    # Retrieve the info values (see the get_info_value helper method below)
    @server = get_info_value(@input_document, 'server')
    @port = get_info_value(@input_document, 'port') || '25'
    @tls = get_info_value(@input_document, 'tls') || 'false'
    @tls = @tls.downcase
    @username = get_info_value(@input_document, 'username')
    @password = get_info_value(@input_document, 'password')

    # Retrieve the parameter values (see the get_parameter_value helper method below)
    @from = get_parameter_value(@input_document, 'from')
    @to = get_parameter_value(@input_document, 'to')
    @subject = get_parameter_value(@input_document, 'subject')
    @htmlbody = get_parameter_value(@input_document, 'htmlbody')
    @textbody = get_parameter_value(@input_document, 'textbody')

    raise "Required parameter 'to' is blank." if @to.nil? || @to.length == 0
  end

  def execute()
    # Create the new email object
    email = org.apache.commons.mail.HtmlEmail.new()

    # Set the required values
    email.setHostName(@server)
    email.setSmtpPort(@port.to_i)
    email.setTLS(@tls == 'true')

    # Unless there was not a user specified
    unless @username.nil? || @username.empty?
      # Set the email authentication
      email.setAuthentication(@username, @password)
    end

    # Set the messages values
    (@to || "").split(/\s*,\s*/).each { |address| email.addTo(address) }
    email.setFrom(@from)
    email.setSubject(@subject)

    # Embed linked images into the html body if it is present
    unless @htmlbody.nil? || @htmlbody.empty?
      # Initialize a hash of image links to embeded values
      embedded_images = {}

      # Iterate over the body and embed necessary images
      @htmlbody.scan(/"cid:(.*)"/) do |match|
        # The match variable is an array of Regex groups (specified with
        # parentheses); in this case the first match is the url
        url = match.first
        # Unless we have already embedded this url
        unless embedded_images.has_key?(url)
          cid = email.embed(url, "Embedded image")
          embedded_images[url] = cid
        end
      end

      # Replace the image URLs with their embedded values
      embedded_images.each do |url, cid|
        @htmlbody.gsub!(url, cid)
      end

      # Set the HTML message
      email.setHtmlMsg(@htmlbody);
    end

    # Set the plaintext message
    email.setTextMsg(@textbody);

    # Send the email
    message_id = email.send();

    # Return the results
    <<-RESULTS
    <results>
      <result name='Message Id'>#{escape(message_id)}</result>
    </results>
    RESULTS
  # If we caught a EmailException error wrapper
  rescue org.apache.commons.mail.EmailException
    # Obtain the actual exception (which is in turn wrapped by NativeException)
    exception = $!.is_a?(NativeException) ? $!.cause : $!
    # Add the real exception string to the stacktrace
    if exception.respond_to?('cause') && exception.cause
      # Modify the message to include the cause
      raise Exception, "#{$!.message} [#{exception.cause.message}]", $!.backtrace
    # Otherwise raise the exception
    else
      raise $!
    end
  end

  # This is a ruby constant that is used by the escape method
  ESCAPE_CHARACTERS = {'&'=>'&amp;', '>'=>'&gt;', '<'=>'&lt;', '"' => '&quot;'}
  # This is a template method that is used to escape results values (returned in
  # execute) that would cause the XML to be invalid.
  def escape(string)
    # Globally replace characters based on the ESCAPE_CHARACTERS constant
    string.gsub(/[&"><]/) { |special| ESCAPE_CHARACTERS[special] }
  end

  # This is a sample helper method that illustrates one method for retrieving
  # values from the input document.  As long as your node.xml document follows
  # the standard format, the get_info_value and get_parameter_value methods are
  # all that are required to retrieve data from the input document.
  def get_info_value(document, name)
    # Retrieve the XML node representing the desird info value
    info_element = REXML::XPath.first(document, "/handler/infos/info[@name='#{name}']")
    # If the desired element is nil, return nil; otherwise return the text value of the element
    info_element.nil? ? nil : info_element.text
  end

  # This is a sample helper method that illustrates one method for retrieving
  # values from the input document.  As long as your node.xml document follows
  # the standard format, the get_info_value and get_parameter_value methods are
  # all that are required to retrieve data from the input document.
  def get_parameter_value(document, name)
    # Retrieve the XML node representing the desird info value
    parameter_element = REXML::XPath.first(document, "/handler/parameters/parameter[@name='#{name}']")
    # If the desired element is nil, return nil; otherwise return the text value of the element
    parameter_element.nil? ? nil : parameter_element.text
  end
end
